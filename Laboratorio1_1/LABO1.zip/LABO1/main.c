
//****************************************************************************
//main.c - Laboratorio 1
// Lampara inteligente
//Autores: Luis Diego Soto, Jose Pablo Avila
//****************************************************************************

#include "msp.h"
#include <driverlib.h>
#include <grlib.h>
#include <HAL_I2C.h>
#include <HAL_OPT3001.h>
#include "labo1.h"
//Declaracion de variables
volatile _Bool g_bParpadeo=true;// true=blink false= don't blink
volatile _Bool g_bEncender;//=false;
uint8_t g_u8BlinkCounter=0; //blink timer count
uint8_t g_u8OnCounter=0;// time on counter
uint8_t g_u8FiveCounter=0;//time counter for five 5s
uint8_t g_u8OneCounter=0;// time counter for 1s
float g_fLux; // lux value gotten from sensor
volatile uint16_t	g_TimerCount =0; // time count
volatile _Bool g_bConvertFlag=false; //true=convert, false=don't convert
volatile _Bool g_bConversionDone=false;// true=conversion done, false= conversion pendings
volatile short g_sAnalogAdj;	//value sampled and adjusted
int g_iAverageFive; // average over 5s
int g_iAverageOne; // average over 1s
_Bool g_bAudioState=false;// false measuring  // true comparing
volatile _Bool g_bSoundCondition=false;// true=loud , false=sound requirement not met
int main(void){

   setup();
// Los 3 LEDs parpadean 3 veces al energizarse
// Una interrupcion enciende y la siguiente apaga
   while(g_bParpadeo)
   {
   ;}

// Obtain lux value from OPT3001
	g_fLux = OPT3001_getLux();
   	if(g_fLux > 50){
   		g_bEncender = true;
    }
   	else{//initial state
   		g_bEncender = false;
   	}

    while(1){
    	if(g_bConvertFlag)
    		 {// Start sampling/conversion
    		ADC14->CTL0 |= ADC14_CTL0_ENC;
    		ADC14->CTL0  |= ADC14_CTL0_SC ;
    		__delay_cycles(5);
    		ADC14->CTL0 &= ~ ADC14_CTL0_SC; }// end sampling

    	if (!g_bEncender){//check_state
    		//g_fLux = OPT3001_getLux();//get light intensity
    		P2->OUT=0;//turn lights off
    		if((g_fLux <= 50) && g_bSoundCondition)
    			{g_bEncender=true;}//turn flag on
    	}
    	else
    	{
    	P2->OUT |= BIT0 | BIT1 | BIT2;} // turn lights on
    	}
    }
void setup(void){
	MAP_WDT_A_holdTimer();
	 /* Initialize I2C communication */
	Init_I2C_GPIO();
	I2C_init();
	/* Initialize OPT3001 digital ambient light sensor */
	OPT3001_init();
	__delay_cycles(100000);
	__disable_irq();
	//------------------------------------------
	// GPIO Setup
	//-----------------------------------------------
	P2->OUT=0;
	P1->OUT=0;
	P2->DIR |= BIT0; //Red led as output , will turn on with PI interrupt
	P1->DIR |= BIT0; //Red led as output, toggles with timer interrupt
	P2->DIR |= BIT1;// Green led as output, toggles with mic
	P2->DIR |=BIT2; //BLUED LED FOR DEBUG
	P4->SEL1 |= BIT3; // Configure P4.3 for ADC
	P4->SEL0 |= BIT3;
	__disable_irq();// desabling interrupt
	//------------------------------------
	// P1 interrupt
	//--------------------------------------
	 //Enabling PORT1 interrupt
	NVIC_SetPriority(PORT1_IRQn,1);
	NVIC_EnableIRQ(PORT1_IRQn);
	// Configuring P1.1 (switch) as input with pull-up
	// resistor. Rest of pins are configured as output low.
	// Notice intentional '=' assignment since all P1 pins are being
	// deliberately configured
	P1->DIR &= ~ (BIT1);
	P1->OUT = BIT1;
	P1->REN = BIT1;                         // Enable pull-up resistor (P1.1 output high)
	P1->SEL0 = 0;
	P1->SEL1 = 0;
	P1->IFG = 0;                            // Clear all P1 interrupt flags
	P1->IES = BIT1;                         // Interrupt on high-to-low transition
	P1->IE = BIT1;                          // Enable interrupt for P1.
	// ****************************
	//       TIMER CONFIG
	// ****************************
	// - Disable all interrupts
	// - Configure Timer A0 with SMCLK, Division by 4, Enable the interrupt
	// - Enable the interrupt in the NVIC
	// - Start the timer in UP mode.
	TIMER_A0->CTL = TIMER_A_CTL_SSEL__SMCLK | TIMER_A_CTL_ID__2 | TIMER_A_CTL_IE;
	//TIMER_A0->EX0 |= TIMER_A_EX0_IDEX__6;
	NVIC_SetPriority(TA0_N_IRQn,1);
	NVIC_EnableIRQ(TA0_N_IRQn);
	TIMER_A0->CCR[0] = 0xFFFF;
	TIMER_A0->CTL |=  TIMER_A_CTL_MC__UP;
	// ****************************
	//       ADC 14 CONFIG
	// ****************************
	// Enable ADC interrupt in NVIC module
	// NVIC->ISER[0] = 1 << ((ADC14_IRQn) & 31);
	ADC14->CTL0 &= ~ADC14_CTL0_ENC;
	NVIC_EnableIRQ(ADC14_IRQn);
	NVIC_SetPriority(ADC14_IRQn,1);
	//  ADC14 on
	ADC14->CTL0 =  ADC14_CTL0_ON | ADC14_CTL0_CONSEQ_0 | ADC14_CTL0_SSEL__MCLK  ; //extended pulse mode
	ADC14->CTL1 = ADC14_CTL1_RES_3 ;         // Use sampling timer, 14-bit conversion results,signed
	ADC14->MCTL[0] = ADC14_MCTLN_INCH_10;   // A10 ADC input select; Vref=AVCC
	ADC14->IER0 |= ADC14_IER0_IE0;          // Enable ADC conv complete interrupt

	//__delay_cycles(10000);
	__enable_irq();
	return;
}

//Subrutinas de atencion a interrupciones
/* Port1 ISR */
void PORT1_ISR(void)
{
    // Toggling the output on the LED
    if(P1->IFG & BIT1)
    	g_bEncender=!g_bEncender; //toggles the lamp state
    P1->IFG &= ~BIT1; // clear flag
   return;
}

/*Timer interrupt*/
void TA0_N_ISR(void)
{
	__disable_irq();
	if(g_TimerCount == TIMERA0_COUNT) // if time count is at ~300ms
	{	//P1->OUT^=BIT0; // toggle p1.1 led for debug purposes
		g_TimerCount=0U; // reset count
		if(g_u8BlinkCounter<=6)// blinking led at powr on
		{
			g_u8BlinkCounter++;
			P2->OUT ^= 0x07;
		}   //this enables the initial blinking
		else
		{
			g_bParpadeo=false;
		}
		if(g_bEncender)     //if lamp is on start counting until it has to be turned off
		{
			if(g_u8OnCounter<108)
			{
				g_u8OnCounter++;
			} //on time implementation
			else
			{
				g_u8OnCounter=0;
				g_bEncender=false;
			}// turn off
		}
		else
		{
			g_u8OnCounter=0;
			g_bConvertFlag=true;
		} // if lamp is off, mic must be sampled
		if(g_bConversionDone)
		{
			g_bConvertFlag=false; // if analog to digital is done, deassert all flags
			g_bConversionDone=false;
			if(~g_bAudioState)
			{
				g_u8FiveCounter++;
				g_iAverageFive+=g_sAnalogAdj;
				if(g_u8FiveCounter==15)   // this gets the sampled audio signal average in 5s
				{
					g_u8FiveCounter=0;
					g_iAverageFive/=15;
					g_bAudioState=true;
				}
			}
			else
			{
				g_u8OneCounter++;
				g_iAverageOne+=g_sAnalogAdj;// this gets the sampled audio signal average in 1s
				if(g_u8OneCounter==3)
				{
					g_u8OneCounter=0;
					g_iAverageOne/=3;
					g_bAudioState=false;

					if(g_iAverageOne>=g_iAverageFive*1.1)
					{
						g_bSoundCondition=true;  // if the 6s have passed by, the comparision is done to see if the sound
												// requirement is met


					}
					else
					{
						g_bSoundCondition=false;

					}
					g_iAverageOne=0;
					g_iAverageFive=0;
				}
			}

		}
	}
	else
	{
		g_TimerCount+=1;
	}

	TIMER_A0->CCTL[0] &= ~TIMER_A_CCTLN_CCIFG;
	__enable_irq();
	return;
}

// ADC14 interrupt service routine
void ADC14_IRQHandler(void)
{
	int l_iBuffer=0;
	l_iBuffer=ADC14->MEM[0];
	g_sAnalogAdj=(l_iBuffer & 0x00007FFC)>>2;
	if((l_iBuffer>> 15)  & 0x01)
		{g_sAnalogAdj-=8192;} // converts to a signed number
	if (abs(g_sAnalogAdj) >=200)
	  P2->OUT |= BIT1;                     //toggle led for debug purposes
	else
	  P2->OUT &= ~BIT1;
    ADC14->CLRIFGR0 |= BIT0;
    g_bConversionDone=true;
    return;
}
