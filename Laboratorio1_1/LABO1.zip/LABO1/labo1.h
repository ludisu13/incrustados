#ifndef labo1_H_
#define labo1_H_

#define NO_ERR 0
#define TIMERA0_COUNT 10000

void setup(void);
void PORT1_ISR(void);
void TA0_N_ISR(void);
void ADC14_IRQHandler(void);
#endif /*labo1_H_ */
