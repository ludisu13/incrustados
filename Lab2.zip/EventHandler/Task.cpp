#include "Task.hpp"

Task::Task()
{

    m_bIsFinished = false;

}


